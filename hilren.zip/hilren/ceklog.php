<?php
session_start();
include "config/conn.php";

// Ambil input dari form
$user = mysqli_real_escape_string($koneksi, $_POST['username']);
$pass_plain = $_POST['password'];
$pass_hash = md5($pass_plain);

// Cek sebagai user admin (tabel: user)
$sql = mysqli_query($koneksi, "SELECT * FROM user WHERE nama='$user' AND pass='$pass_hash'");
if (mysqli_num_rows($sql) > 0) {
    $rs = mysqli_fetch_array($sql);

    $_SESSION['idu']   = $rs['idu'];
    $_SESSION['nama']  = $rs['nama'];
    $_SESSION['level'] = $rs['level'];
    $_SESSION['idk']   = "";
    $_SESSION['ortu']  = "";
    $_SESSION['id']    = $rs['id'];

    header('Location: media.php?module=home');
    exit;
}

// Cek sebagai siswa (tabel: siswa)
$sql_siswa = mysqli_query($koneksi, "SELECT * FROM siswa WHERE nis='$user' AND pass='$pass_hash'");
if (mysqli_num_rows($sql_siswa) > 0) {
    $rsa = mysqli_fetch_array($sql_siswa);

    $_SESSION['idu']   = $rsa['nis'];
    $_SESSION['nama']  = $rsa['nama'];
    $_SESSION['level'] = "user";
    $_SESSION['ortu']  = $pass_plain;
    $_SESSION['idk']   = $rsa['idk'];
    $_SESSION['id']    = "2";

    header('Location: media.php?module=home');
    exit;
}

// Cek sebagai guru (tabel: guru)
$sql_guru = mysqli_query($koneksi, "SELECT * FROM guru WHERE nip='$user' AND pass='$pass_hash'");
if (mysqli_num_rows($sql_guru) > 0) {
    $rsz = mysqli_fetch_array($sql_guru);

    $_SESSION['idu']   = $rsz['nip'];
    $_SESSION['nama']  = $rsz['nama'];
    $_SESSION['idk']   = $rsz['idk'];
    $_SESSION['level'] = "guru";
    $_SESSION['ortu']  = "";
    $_SESSION['id']    = "2";

    header('Location: media.php?module=home');
    exit;
}

// Jika semua gagal login
echo "<script>alert('Mohon periksa kembali Username & Password Anda'); location.href='login.php';</script>";
?>