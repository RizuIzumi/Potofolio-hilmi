<?php
include 'config/conn.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = md5($_POST["password"]); // disamakan dengan ceklog.php
    $level    = $_POST["level"];
    $id       = $_POST["id"]; // id sekolah

    $sql = "INSERT INTO user (idu, nama, pass, level, id) 
            VALUES (NULL, '$username', '$password', '$level', '$id')";

    if (mysqli_query($koneksi, $sql)) {
        echo "<script>alert('Register berhasil! Silakan login.'); window.location='login.php';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($koneksi);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - SISTEM ABSENSI SISWA</title>
    <link rel="stylesheet" href="style.css"> <!-- CSS neon-gradient -->
</head>
<body>
    <div class="container">
        <div class="form-box">
            <h2>Website Absensi</h2>
            <h3>Register</h3>
            <form method="post">
                <input type="text" name="username" placeholder="Username" required>
                <input type="password" name="password" placeholder="Password" required>

                <!-- pilih level -->
                <select name="level" required>
                    <option value="">-- Pilih Level --</option>
                    <option value="admin">Admin</option>
                    <option value="siswa">Siswa</option>
                    <option value="guru">Guru</option>
                </select>

                <!-- pilih sekolah -->
                <select name="id" required>
                    <option value="">-- Pilih Sekolah --</option>
                    <option value="1">SMK KARTINI BHAKTI MANDIRI</option>
                    <option value="2">SMK 4 LPPM RI PADALARANG</option>
                    <option value="3">SMK NEGERI 4 PADALARANG</option>
                    <?php
                    $qSekolah = mysqli_query($koneksi, "SELECT * FROM sekolah");
                    while ($row = mysqli_fetch_assoc($qSekolah)) {
                        echo "<option value='".$row['id']."'>".$row['nama_sekolah']."</option>";
                    }
                    ?>
                </select>

                <button type="submit">Register</button>
                <p>Sudah punya akun? <a href="login.php">Login</a></p>
            </form>
        </div>
    </div>
</body>
</html>
