function showLogin() {
  document.querySelector(".login-box").classList.remove("hidden");
  document.querySelector(".register-box").classList.add("hidden");
}

function showRegister() {
  document.querySelector(".register-box").classList.remove("hidden");
  document.querySelector(".login-box").classList.add("hidden");
}