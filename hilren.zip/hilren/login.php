<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SISTEM ABSENSI SISWA</title>
    <link rel="stylesheet" href="style.css"> <!-- CSS neon-gradient -->
</head>
<body>
    <?php
    include 'config/conn.php';
    $sql = mysqli_query($koneksi, "SELECT * FROM sekolah WHERE id='2'");
    $rs = mysqli_fetch_array($sql);
    ?>

    <div class="container">
        <div class="form-box">
            <h2>Website Absensi</h2>
            <h3>Login</h3>
            <form method="post" action="ceklog.php">
                <input type="text" name="username" placeholder="Username" required autofocus>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit">Login</button>
                <p>Belum punya akun? <a href="register.php">Register</a></p>
            </form>
        </div>
    </div>
</body>
</html>
