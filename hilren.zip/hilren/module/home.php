<?php
// Ambil data dari database (opsional untuk statistik)
$jml_siswa = mysqli_fetch_array(mysqli_query($koneksi, "SELECT COUNT(*) as total FROM siswa"))['total'];
$jml_guru = mysqli_fetch_array(mysqli_query($koneksi, "SELECT COUNT(*) as total FROM guru"))['total'];
$jml_kelas = mysqli_fetch_array(mysqli_query($koneksi, "SELECT COUNT(*) as total FROM kelas"))['total'];
$jml_mapel = mysqli_fetch_array(mysqli_query($koneksi, "SELECT COUNT(*) as total FROM mata_pelajaran"))['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
/* Tambahan biar lebih modern */
.panel-siswa .panel-heading {
    background-color: #1eddffff; /* Biru */
    color: #fff;
}
.panel-guru .panel-heading {
    background-color: #00b894; /* Hijau tegas */
    color: #fff;
}
.panel-kelas .panel-heading {
    background-color: #6c5ce7; /* Ungu solid */
    color: #fff;
}
.panel-mapel .panel-heading {
    background-color: #d63031; /* Merah solid */
    color: #fff;
}
/* Angka di dalam panel heading */
.count-siswa {
    color: #ffffffff; /* Emas untuk siswa */
    font-weight: bold;
}
.count-guru {
    color: #ffffffff; /* Hijau neon */
    font-weight: bold;
}
.count-kelas {
    color: #f9f8f8ff; /* Merah terang */
    font-weight: bold;
}
.count-mapel {
    color: #f8f9fa; /* Putih terang */
    font-weight: bold;
}
.panel-footer {
    background: #f4f7fb !important;
    font-weight: bold;
}
.heading {
    padding: 20px;
    color: #4242ecff !important;
}
.panel {
    border-radius: 12px;
    transition: 0.3s;
}
.panel:hover {
    transform: scale(1.05);
}
.panel-heading {
    padding: 20px;
    color: #fff !important;
}
.shadow {
    box-shadow: 0 4px 8px rgba(0,0,0,0.15);
}
.panel-footer {
    background: #f4f7fb !important;
}
.logo-sekolah {
    max-width: 150px;     /* ukuran maksimal logo */
    border-radius: 50%;   /* biar bulat kalau logonya kotak */
    box-shadow: 0 4px 12px rgba(0,0,0,0.3); /* efek bayangan */
    margin-top: 20px;
    transition: transform 0.3s ease;
}
.logo-sekolah:hover {
    transform: scale(1.1); /* efek zoom saat hover */
}
.logo{
    background-image: url(module/logo.png);
    background-repeat: no repeat;
    width: 290px;
    height: 310px;
    display: block;
    margin: 0 auto;
}
</style>
</head>
<body>
    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header"><strong>Dashboard</strong></h2>
        </div>
    </div>
    <!-- Logo Sekolah di Tengah -->
    <div class="row">
        <div class="col-lg-12 text-center">
            <div class="logo">
                <!-- <img src="./img/logo.png" style="max-width:200px; margin-bottom:15px;" alt="" srcset=""> -->
            </div>
            <!-- <img src="img/logo.png" alt="Logo Sekolah" class="logo-sekolah" style="max-width:200px; margin-bottom:15px;"> -->
            <h2 style="font-weight:bold; color:#1e90ff;">
                Selamat Datang di Sistem Informasi Sekolah
            </h2>
        </div>
    </div>
    <hr>
    
    <!-- Statistik Cards -->
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-siswa shadow">
            <div class="panel-heading text-center">
                <i class="fa fa-users fa-3x"></i>
                <h4>Siswa</h4>
                <h3 class="count-siswa"><?= $jml_siswa; ?></h3>
            </div>
            <a href="media.php?module=siswa">
                <div class="panel-footer text-center">
                    <span class="pull-left">Lihat Detail</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
    
    <!-- Guru -->
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-guru shadow">
            <div class="panel-heading text-center">
                <i class="fa fa-user fa-3x"></i>
                <h4>Guru</h4>
                <h3 class="count-guru"><?= $jml_guru; ?></h3>
            </div>
            <a href="media.php?module=guru">
                <div class="panel-footer text-center">
                    <span class="pull-left">Lihat Detail</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
    
    <!-- Kelas -->
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-kelas shadow">
            <div class="panel-heading text-center">
                <i class="fa fa-home fa-3x"></i>
                <h4>Kelas</h4>
                <h3 class="count-kelas"><?= $jml_kelas; ?></h3>
            </div>
            <a href="media.php?module=kelas">
                <div class="panel-footer text-center">
                    <span class="pull-left">Lihat Detail</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
    
    <!-- Mata Pelajaran -->
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-mapel shadow">
            <div class="panel-heading text-center">
                <i class="fa fa-book fa-3x"></i>
                <h4>Mata Pelajaran</h4>
                <h3 class="count-mapel"><?= $jml_mapel; ?></h3>
            </div>
            <a href="media.php?module=mata_pelajaran">
                <div class="panel-footer text-center">
                    <span class="pull-left">Lihat Detail</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
    
    
    <!-- Selamat Datang -->
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default shadow">
                <div class="heading"><i class="fa fa-home"></i> Selamat Datang</div>
                <div class="panel-body">
                    <p>
                        Halo <strong><?= $_SESSION['nama']; ?></strong>, selamat datang di 
                        <b>Sistem Absensi Siswa</b>.  
                        Silakan gunakan menu di samping untuk mengelola data.
                    </p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>