<?php
// Gunakan koneksi mysqli dan proteksi variabel input
require '/../../../config/conn.php';
$acuan = isset($_GET['idj']) ? intval($_GET['idj']) : 0;
$tgl_lengkap = isset($_GET['tgl_lengkap']) ? htmlspecialchars($_GET['tgl_lengkap']) : date('d F Y');

// Ambil data jadwal
$sqlacuan = mysqli_query($koneksi, "SELECT * FROM jadwal WHERE idj='$acuan'");
$rss = mysqli_fetch_assoc($sqlacuan);

$sqlkss = mysqli_query($koneksi, "SELECT * FROM kelas WHERE idk='{$rss['idk']}'");
$kss = mysqli_fetch_assoc($sqlkss);

$sqlmp = mysqli_query($koneksi, "SELECT * FROM mata_pelajaran WHERE idm='{$rss['idm']}'");
$nama_mp = mysqli_fetch_assoc($sqlmp);

$sqlidh = mysqli_query($koneksi, "SELECT * FROM hari WHERE idh='{$rss['idh']}'");
$nama_hari = mysqli_fetch_assoc($sqlidh);

// Proses tahun ajaran
$pecah = explode(" ", $tgl_lengkap);
$satu = $pecah[0];
$dua = $pecah[1];
$tahun1 = intval($pecah[2]);
$tahun2 = ($dua == "Juli" || $dua == "Agustus" || $dua == "September" || $dua == "Oktober" || $dua == "November" || $dua == "Desember") ? $tahun1 + 1 : $tahun1 - 1;
$tahun_ajaran = ($dua == "Juli" || $dua == "Agustus" || $dua == "September" || $dua == "Oktober" || $dua == "November" || $dua == "Desember") ? "$tahun1 - $tahun2" : "$tahun2 - $tahun1";
?>

<div class="row">
  <div class="col-lg-12">
    <h3 class="page-header">
      <strong>Tahun Ajaran <?php echo $tahun_ajaran; ?></strong>
      <form action="module/laporan/guru/cetak_rekap.php" method="post" style="display:inline; float:right; margin-top:-40px;">
        <input type="hidden" name="idj" value="<?php echo $acuan; ?>">
        <input type="hidden" name="tgl_lengkap" value="<?php echo $tgl_lengkap; ?>">
        <input class="btn btn-success btn-lg" type="submit" name="cetak" value="Cetak">
      </form>
    </h3>
  </div>
</div>

<div class="row">
  <div class="col-lg-12">
    <div class="panel panel-primary">
      <div class="panel-heading">
        Data Absensi Kelas <b><?php echo $kss['nama'] . " | " . $nama_mp['nama_mp']; ?></b>
      </div>
      <div class="panel-body">
        <div class="table-responsive">
          <?php
          $sqlabsen = mysqli_query($koneksi, "SELECT DISTINCT tgl FROM absen WHERE idj='$acuan' ORDER BY tgl ASC");
          $jumlahtanggal = mysqli_num_rows($sqlabsen);
          $jumlahkolom = $jumlahtanggal + 1;
          ?>
          <table class="table table-striped table-bordered table-hover">
            <tr>
              <td colspan="<?php echo $jumlahkolom; ?>" class="text-center info">
                <b><?php echo $nama_hari['hari'] . ", " . $rss['jam_mulai'] . " - " . $rss['jam_selesai']; ?></b>
              </td>
            </tr>
            <tr>
              <td class="success text-center" rowspan="2"><b>Siswa</b></td>
              <td colspan="<?php echo $jumlahtanggal; ?>" class="text-center success"><b>Tanggal (TGL/BLN)</b></td>
            </tr>
            <tr>
              <?php while ($tglnya = mysqli_fetch_assoc($sqlabsen)) {
                $pecah = explode("-", $tglnya['tgl']);
                echo "<td class='text-center warning'><b>{$pecah[2]}/{$pecah[1]}</b></td>";
              } ?>
            </tr>
            <?php
            $sqlrss = mysqli_query($koneksi, "SELECT * FROM siswa WHERE idk='{$rss['idk']}'");
            while ($siswanya = mysqli_fetch_assoc($sqlrss)) {
              echo "<tr><td class='text-center warning'>{$siswanya['nama']}</td>";
              $sqlabsen2 = mysqli_query($koneksi, "SELECT ket FROM absen WHERE ids='{$siswanya['ids']}' AND idj='$acuan' ORDER BY tgl ASC");
              while ($ketnya = mysqli_fetch_assoc($sqlabsen2)) {
                echo "<td class='text-center'>{$ketnya['ket']}</td>";
              }
              echo "</tr>";
            }
            ?>
          </table>
        </div>

        <div class="well">
          <h4>Keterangan Absensi</h4>
          <p>A = Tidak Masuk Tanpa Keterangan</p>
          <p>I = Tidak Masuk Ada Surat Ijin Atau Pemberitahuan</p>
          <p>S = Tidak Masuk Ada Surat Dokter Atau Pemberitahuan</p>
          <p>M = Hadir</p>
        </div>
      </div>
    </div>
  </div>
</div>