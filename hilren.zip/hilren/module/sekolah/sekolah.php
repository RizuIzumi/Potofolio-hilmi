<?php
include __DIR__ . "/../../config/conn.php";
?>

<div class="row">
    <div class="col-lg-12">
        <h3 class="page-header"><strong>Data Sekolah</strong></h3>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-primary">
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover">
                        <thead>
                            <tr>
                                <th class="text-center">Kode</th>
                                <th class="text-center">Nama Sekolah</th>
                                <th class="text-center">Alamat</th>
                                <th class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sql = mysqli_query($koneksi, "SELECT * FROM sekolah");
                            while ($rs = mysqli_fetch_assoc($sql)) {
                                ?>
                                <tr class="odd gradeX">
                                    <td><?php echo htmlspecialchars($rs['kode']); ?></td>
                                    <td><?php echo htmlspecialchars($rs['nama']); ?></td>
                                    <td><?php echo htmlspecialchars($rs['alamat']); ?></td>
                                    <td class="text-center">
                                        <a href="./././media.php?module=input_sekolah&act=edit_sekolah&id=<?php echo $rs['id']; ?>">
                                            <button type="button" class="btn btn-info">Edit</button>
                                        </a>
                                    </td>
                                </tr>
                                <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div> <!-- /.table-responsive -->
            </div> <!-- /.panel-body -->
        </div> <!-- /.panel -->
    </div> <!-- /.col-lg-12 -->
</div> <!-- /.row -->