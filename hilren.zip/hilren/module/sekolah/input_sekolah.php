<?php
if ($_GET['act'] == "edit_sekolah") {
    include __DIR__ . "/../../config/conn.php";
    $id = mysqli_real_escape_string($koneksi, $_GET['id']);
    $sql = mysqli_query($koneksi, "SELECT * FROM sekolah WHERE id='$id'");
    $rs = mysqli_fetch_assoc($sql);
    ?>
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Edit Data Sekolah</h1>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    Edit Data Sekolah
                </div>
                <div class="panel-body">
                    <div class="row">
                        <form method="post" role="form" action="././module/simpan.php?act=edit_sekolah">
                            <input type="hidden" name="id" value="<?php echo htmlspecialchars($rs['id']); ?>" />
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Kode Sekolah</label>
                                    <input class="form-control" name="kode" placeholder="Kode"
                                           value="<?php echo htmlspecialchars($rs['kode']); ?>">
                                </div>
                                <div class="form-group">
                                    <label>Nama Sekolah</label>
                                    <input class="form-control" name="nama" placeholder="Nama Sekolah"
                                           value="<?php echo htmlspecialchars($rs['nama']); ?>">
                                </div>
                                <div class="form-group">
                                    <label>Alamat</label>
                                    <textarea class="form-control" name="alamat" placeholder="Alamat" rows="3"><?php echo htmlspecialchars($rs['alamat']); ?></textarea>
                                </div>
                                <button type="submit" class="btn btn-success">Simpan</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php } ?>