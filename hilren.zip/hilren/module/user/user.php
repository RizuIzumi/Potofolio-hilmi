<?php
// Pastikan koneksi database sudah dibuat sebelumnya di $koneksi
?>

<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">Data User</h1>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-primary">
            <div class="panel-heading">Data User</div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th class="text-center">User Name</th>
                                <th class="text-center">Level</th>
                                <th class="text-center">Sekolah</th>
                                <th class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
<?php
if ($_SESSION['level'] == "admin_guru") {
    $idu = intval($_SESSION['idu']);
    $sql = mysqli_query($koneksi, "SELECT u.*, s.nama as nama_sekolah 
                                 FROM user u 
                                 LEFT JOIN sekolah s ON u.id = s.id 
                                 WHERE u.idu = $idu");
} else {
    $sql = mysqli_query($koneksi, "SELECT u.*, s.nama as nama_sekolah 
                                 FROM user u 
                                 LEFT JOIN sekolah s ON u.id = s.id 
                                 WHERE u.idu <> 1");
}

while ($rs = mysqli_fetch_assoc($sql)) {
?>
                            <tr class="odd gradeX">
                                <td><?php echo htmlspecialchars($rs['nama']); ?></td>
                                <td class="text-center"><?php echo htmlspecialchars($rs['level']); ?></td>
                                <td class="text-center"><?php echo htmlspecialchars($rs['nama_sekolah']); ?></td>
                                <td class="text-center">
                                    <a href="./media.php?module=input_user&act=edit_user&idu=<?php echo intval($rs['idu']); ?>" class="btn btn-info btn-sm">Edit</a>
                                    <?php if ($_SESSION['level'] != "admin_guru") { ?>
                                        <a href="./module/simpan.php?act=hapus_user&idu=<?php echo intval($rs['idu']); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus user ini?')">Hapus</a>
                                    <?php } ?>
                                </td>
                            </tr>
<?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>