<?php
include "../config/conn.php";

if (isset($_GET['act']) && $_GET['act'] == "input") {
?>
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">Input Data User</h1>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-primary">
            <div class="panel-heading">Input Data User</div>
            <div class="panel-body">
                <div class="row">
                    <form method="post" role="form" action="././module/simpan.php?act=input_user">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Username</label>
                                <input class="form-control" placeholder="Username" name="nama" required>
                            </div>
                            <div class="form-group">
                                <label>Password</label>
                                <input type="password" class="form-control" placeholder="Password" name="pass" required>
                            </div>
                            <div class="form-group">
                                <label>Sekolah</label>
                                <select class="form-control" name="sekolah" required>
                                    <?php
                                    $sqla = mysqli_query($koneksi, "SELECT * FROM sekolah");
                                    while ($rsa = mysqli_fetch_assoc($sqla)) {
                                        echo "<option value='{$rsa['id']}'>" . htmlspecialchars($rsa['nama']) . "</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-success">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
}

if (isset($_GET['act']) && $_GET['act'] == "edit_user") {
    $idu = intval($_GET['idu']);
    $sql = mysqli_query($koneksi, "SELECT * FROM user WHERE idu = '$idu'");
    $rs = mysqli_fetch_assoc($sql);
?>
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">Edit Data User</h1>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-primary">
            <div class="panel-heading">Edit Data User</div>
            <div class="panel-body">
                <div class="row">
                    <form method="post" role="form" action="././module/simpan.php?act=edit_user">
                        <input type="hidden" name="idu" value="<?php echo $idu; ?>">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Username</label>
                                <input class="form-control" placeholder="Username" name="nama" value="<?php echo htmlspecialchars($rs['nama']); ?>" required>
                            </div>
                            <div class="form-group">
                                <label>Password</label>
                                <input type="password" class="form-control" placeholder="Kosongkan jika tidak diubah" name="pass">
                            </div>
                            <div class="form-group">
                                <label>Sekolah</label>
                                <select class="form-control" name="sekolah" required>
                                    <?php
                                    $sqla = mysqli_query($koneksi, "SELECT * FROM sekolah");
                                    while ($rsa = mysqli_fetch_assoc($sqla)) {
                                        $selected = ($rs['id'] == $rsa['id']) ? 'selected' : '';
                                        echo "<option value='{$rsa['id']}' $selected>" . htmlspecialchars($rsa['nama']) . "</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-success">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
}
?>