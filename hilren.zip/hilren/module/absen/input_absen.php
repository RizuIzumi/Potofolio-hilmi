<?php
// Koneksi DB dan proteksi input
include __DIR__ . '/../../config/conn.php'; 
include __DIR__ . '/../../config/fungsi.php'; 

$idj = isset($_GET['idj']) ? (int)$_GET['idj'] : 0;
$tanggal = date("Y-m-d");

$dataquery = mysqli_query($koneksi, "SELECT * FROM jadwal WHERE idj = $idj");
$arrayj = mysqli_fetch_assoc($dataquery);

$datamp = mysqli_query($koneksi, "SELECT * FROM mata_pelajaran WHERE idm = '{$arrayj['idm']}'");
$arraymp = mysqli_fetch_assoc($datamp);

$sqlj = mysqli_query($koneksi, "SELECT * FROM kelas WHERE idk = '{$arrayj['idk']}'");
$rsj = mysqli_fetch_assoc($sqlj);
?>

<div class="row">
  <div class="col-lg-12">
    <h3 class="page-header"><strong>Input Data Absensi</strong></h3>
  </div>
</div>
<div class="row">
  <div class="col-lg-12">
    <div class="panel panel-primary">
      <div class="panel-heading">
        <?php echo "Kelas {$rsj['nama']} | {$arraymp['nama_mp']}"; ?>
      </div>
      <div class="panel-body">
        <div class="table-responsive">
          <form method="post" action="././module/simpan.php?act=input_absen&idj=<?php echo $idj ?>&tanggal=<?php echo $tanggal ?>&kelas=<?php echo $arrayj['idk'] ?>">
            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
              <thead>
                <tr>
                  <th class="text-center">NIS</th>
                  <th class="text-center">Nama</th>
                  <th class="text-center">Keterangan</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $sqlsiswa = mysqli_query($koneksi, "SELECT * FROM siswa WHERE idk = '{$arrayj['idk']}'");
                while ($rs = mysqli_fetch_assoc($sqlsiswa)) {
                  $ids = $rs['ids'];
                  $sqlabsen = mysqli_query($koneksi, "SELECT * FROM absen WHERE ids = '$ids' AND tgl = '$tanggal' AND idj = '$idj'");
                  $rsa = mysqli_fetch_assoc($sqlabsen);
                  $ket = $rsa['ket'] ?? 'N';
                  ?>
                  <tr class="odd gradeX">
                    <td><?php echo $rs['nis']; ?></td>
                    <td><?php echo $rs['nama']; ?></td>
                    <td class="text-center">
                      <div class="form-group">
                        <?php
                        $opsi = ['A', 'I', 'S', 'M', 'N'];
                        foreach ($opsi as $opt) {
                          $checked = ($ket == $opt) ? 'checked' : '';
                          echo "<label class='radio-inline'><input type='radio' name='{$ids}' value='{$opt}' {$checked}>{$opt}</label> ";
                        }
                        ?>
                      </div>
                    </td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
            <button type="submit" class="btn btn-success">Simpan Data Absen</button>
          </form>
        </div>
        <br>
        <div class="well">
          <h4>Keterangan Absensi</h4>
          <p>A = Tidak Masuk Tanpa Keterangan</p>
          <p>I = Tidak Masuk Ada Surat Ijin Atau Pemberitahuan</p>
          <p>S = Tidak Masuk Ada Surat Dokter Atau Pemberitahuan</p>
          <p>M = Hadir</p>
          <p>N = Belum di Absen</p>
        </div>
      </div>
    </div>
  </div>
</div>