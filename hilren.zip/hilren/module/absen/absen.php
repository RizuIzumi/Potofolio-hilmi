<?php
session_start();
include __DIR__ . '/../../config/conn.php'; // Pastikan path ini benar
include __DIR__ . '/../../config/fungsi.php'; // Fungsi hari_ina()

$today = hari_ina(date("l"));
$now = date("H:i:s");

// Ambil ID hari sekarang
$query = mysqli_query($koneksi, "SELECT * FROM hari WHERE hari='$today'");
$id_hari = mysqli_fetch_assoc($query);

if ($id_hari) {
    $idh = (int)$id_hari['idh'];

    // Set semua jadwal tidak aktif dulu
    mysqli_query($koneksi, "UPDATE jadwal SET aktif = 0");

    // Aktifkan jadwal yang sesuai hari dan waktu sekarang
    mysqli_query($koneksi, "
        UPDATE jadwal 
        SET aktif = 1 
        WHERE idh = $idh 
        AND jam_mulai <= '$now' 
        AND jam_selesai >= '$now'
    ");

    // Cek apakah jadwal yang dimaksud sedang aktif
    $idj = isset($_GET['idj']) ? (int)$_GET['idj'] : 0;
    $result = mysqli_query($koneksi, "SELECT * FROM jadwal WHERE idj = $idj LIMIT 1");
    $jadwal = mysqli_fetch_assoc($result);

    if ($jadwal && $jadwal['aktif'] == 1) {
        include "input_absen.php";
    } else {
        echo "<center><br><h3>Maaf, Anda tidak bisa mengabsen siswa di luar jam pelajaran.</h3>
        <a href='media.php?module=jadwal_mengajar'><b>Kembali</b></a></center>";
    }
} else {
    echo "<center><h3>Hari ini tidak ditemukan dalam tabel hari.</h3></center>";
}
?>