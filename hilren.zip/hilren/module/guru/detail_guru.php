<?php
include __DIR__ . "/../../config/conn.php"; // file ini harus berisi: $koneksi = mysqli_connect(...);

// Amankan input GET
$idg = isset($_GET['idg']) ? mysqli_real_escape_string($koneksi, $_GET['idg']) : '';

// Ambil data guru
$sql = mysqli_query($koneksi, "SELECT * FROM guru WHERE idg='$idg'");
$rs = mysqli_fetch_assoc($sql);
?>

<div class="row">
    <div class="col-lg-12">
        <h3 class="page-header"><strong>Data Guru: <?= htmlspecialchars($rs['nama']) ?></strong></h3>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-primary">
            <div class="panel-heading">
                Data Guru
            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-6">
                        <fieldset disabled>
                            <div class="form-group">
                                <label>NIP</label><br>
                                <label><?= htmlspecialchars($rs['nip']) ?></label>
                            </div>

                            <div class="form-group">
                                <label>Nama</label>
                                <input class="form-control" placeholder="Nama" name="nama" value="<?= htmlspecialchars($rs['nama']) ?>">
                            </div>

                            <div class="form-group">
                                <label>Jenis Kelamin</label>
                                <div class="radio">
                                    <label>
                                        <input type="radio" name="jk" value="L" <?= ($rs['jk'] == "L") ? "checked" : "" ?>>
                                        Laki - Laki
                                    </label>
                                </div>
                                <div class="radio">
                                    <label>
                                        <input type="radio" name="jk" value="P" <?= ($rs['jk'] == "P") ? "checked" : "" ?>>
                                        Perempuan
                                    </label>
                                </div>
                            </div>
                        </fieldset>
                    </div>

                    <div class="col-lg-6">
                        <div class="form-group">
                            <label>Alamat</label>
                            <textarea class="form-control" placeholder="Alamat" name="alamat" rows="3" disabled><?= htmlspecialchars($rs['alamat']) ?></textarea>
                        </div>
                    </div>
                </div> <!-- /.row (nested) -->
            </div> <!-- /.panel-body -->
        </div> <!-- /.panel -->
    </div> <!-- /.col-lg-12 -->
</div> <!-- /.row -->