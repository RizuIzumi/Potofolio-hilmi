<?php
include __DIR__ . "/../../config/conn.php"; // Pastikan koneksi tersedia sebagai $koneksi

if ($_GET['act'] == "input") {
?>
<div class="row">
    <div class="col-lg-12">
        <h3 class="page-header"><strong>Input Data Guru</strong></h3>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-primary">
            <div class="panel-heading">Input Data Guru</div>
            <div class="panel-body">
                <div class="row">
                    <form method="post" role="form" action="././module/simpan.php?act=input_guru">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>NIP</label>
                                <input class="form-control" placeholder="NIP" name="nip" required>
                            </div>
                            <div class="form-group">
                                <label>Nama</label>
                                <input class="form-control" placeholder="Nama" name="nama" required>
                            </div>
                            <div class="form-group">
                                <label>Jenis Kelamin</label>
                                <div class="radio">
                                    <label><input type="radio" name="jk" value="L" checked> Laki - Laki</label>
                                </div>
                                <div class="radio">
                                    <label><input type="radio" name="jk" value="P"> Perempuan</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Alamat</label>
                                <textarea class="form-control" placeholder="Alamat" name="alamat" rows="3"></textarea>
                            </div>
                            <div class="form-group">
                                <label>Password</label>
                                <input class="form-control" placeholder="Password" name="k_password" type="password" required>
                            </div>
                            <br>
                            <button type="submit" class="btn btn-success">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
} elseif ($_GET['act'] == "edit_guru") {
    $idg = $_GET['idg'];
    $query = mysqli_query($koneksi, "SELECT * FROM guru WHERE idg='$idg'");
    $rs = mysqli_fetch_assoc($query);
?>
<div class="row">
    <div class="col-lg-12">
        <h3 class="page-header"><strong>Edit Data Guru</strong></h3>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-primary">
            <div class="panel-heading">Edit Data Guru</div>
            <div class="panel-body">
                <div class="row">
                    <form method="post" role="form" action="././module/simpan.php?act=edit_guru">
                        <input type="hidden" name="idg" value="<?= htmlspecialchars($rs['idg']) ?>">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>NIP</label>
                                <input class="form-control" required placeholder="NIP" name="nip" value="<?= htmlspecialchars($rs['nip']) ?>">
                            </div>
                            <div class="form-group">
                                <label>Nama</label>
                                <input class="form-control" placeholder="Nama" name="nama" value="<?= htmlspecialchars($rs['nama']) ?>">
                            </div>
                            <div class="form-group">
                                <label>Jenis Kelamin</label>
                                <div class="radio">
                                    <label><input type="radio" name="jk" value="L" <?= $rs['jk'] == 'L' ? 'checked' : '' ?>> Laki - Laki</label>
                                </div>
                                <div class="radio">
                                    <label><input type="radio" name="jk" value="P" <?= $rs['jk'] == 'P' ? 'checked' : '' ?>> Perempuan</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Alamat</label>
                                <textarea class="form-control" placeholder="Alamat" name="alamat" rows="3"><?= htmlspecialchars($rs['alamat']) ?></textarea>
                            </div>
                            <div class="form-group">
                                <label>Password</label>
                                <input class="form-control" placeholder="Password" name="k_password" type="password">
                            </div>
                            <button type="submit" class="btn btn-success">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
}
?>