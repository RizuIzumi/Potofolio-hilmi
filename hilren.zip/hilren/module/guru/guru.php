<?php
include __DIR__ . "/../../config/conn.php"; // pastikan $koneksi tersedia
$no = 1;
$sql = mysqli_query($koneksi, "SELECT * FROM guru");
?>

<div class="row">
    <div class="col-lg-12">
        <h3 class="page-header"><strong>Data Guru</strong></h3>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-primary">
            <div class="panel-heading">Data Guru</div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th class="text-center">NIP</th>
                                <th class="text-center" width="50%">Nama</th>
                                <th class="text-center">JK</th>
                                <th class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($rs = mysqli_fetch_assoc($sql)) { ?>
                            <tr class="odd gradeX">
                                <td class="text-center"><?= htmlspecialchars($rs['nip']) ?></td>
                                <td><?= htmlspecialchars($rs['nama']) ?></td>
                                <td class="text-center">
                                    <?= ($rs['jk'] == "L") ? "Laki - Laki" : "Perempuan" ?>
                                </td>
                                <td class="text-center">
                                    <a href="media.php?module=detail_guru&idg=<?= $rs['idg'] ?>" class="btn btn-warning btn-sm">Detail</a>
                                    <a href="media.php?module=input_guru&act=edit_guru&idg=<?= $rs['idg'] ?>" class="btn btn-info btn-sm">Edit</a>
                                    <a href="module/simpan.php?act=hapus_guru&idg=<?= $rs['idg'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</a>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div> <!-- /.table-responsive -->
            </div> <!-- /.panel-body -->
        </div> <!-- /.panel -->
    </div> <!-- /.col-lg-12 -->
</div> <!-- /.row -->