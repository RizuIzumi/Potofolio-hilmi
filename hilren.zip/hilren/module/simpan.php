<?php
// Gunakan koneksi MySQLi atau PDO dan hindari MySQL extension yang sudah deprecated
require_once dirname(__DIR__) . '/config/conn.php';

// Fungsi untuk membersihkan input
function clean_input($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

// Escape function (gunakan sesuai sistem koneksi: mysqli / PDO)
function esc($koneksi, $data) {
    return mysqli_real_escape_string($koneksi, clean_input($data));
}

$act = $_GET['act'] ?? '';

switch ($act) {
    case "input_user":
        $nama = esc($koneksi, $_POST['nama']);
        $pw = password_hash($_POST['pass'], PASSWORD_DEFAULT);
        $sekolah = esc($koneksi, $_POST['sekolah']);

        $query = "INSERT INTO user(nama, pass, level, id) VALUES ('$nama', '$pw', 'admin_guru', '$sekolah')";
        mysqli_query($koneksi, $query);
        break;

    case "edit_user":
        $idu = esc($koneksi, $_POST['idu']);
        $nama = esc($koneksi, $_POST['nama']);
        $sekolah = esc($koneksi, $_POST['sekolah']);
        if (!empty($_POST['pass'])) {
            $pw = password_hash($_POST['pass'], PASSWORD_DEFAULT);
            $query = "UPDATE user SET nama='$nama', pass='$pw', id='$sekolah' WHERE idu='$idu'";
        } else {
            $query = "UPDATE user SET nama='$nama', id='$sekolah' WHERE idu='$idu'";
        }
        mysqli_query($koneksi, $query);
        break;

    case "hapus_user":
        $idu = esc($koneksi, $_GET['idu']);
        mysqli_query($koneksi, "DELETE FROM user WHERE idu='$idu'");
        break;

    case "input_siswa":
        $mr = password_hash($_POST['k_password'], PASSWORD_DEFAULT);
        $fields = ['nis','nama','jk','alamat','kelas','tlp','bapak','k_bapak','ibu','k_ibu'];
        $data = array_map(function($field) use ($koneksi) {
            return esc($koneksi, $_POST[$field]);
        }, $fields);
        mysqli_query($koneksi, "INSERT INTO siswa(nis,nama,jk,alamat,idk,tlp,bapak,k_bapak,ibu,k_ibu,pass) VALUES ('$data[0]','$data[1]','$data[2]','$data[3]','$data[4]','$data[5]','$data[6]','$data[7]','$data[8]','$data[9]','$mr')");
        break;

    case "edit_siswa":
        $id = esc($koneksi, $_POST['id']);
        $mr = password_hash($_POST['k_password'], PASSWORD_DEFAULT);
        $fields = ['nis','nama','jk','alamat','kelas','tlp','bapak','k_bapak','ibu','k_ibu'];
        $data = array_map(function($field) use ($koneksi) {
            return esc($koneksi, $_POST[$field]);
        }, $fields);
        mysqli_query($koneksi, "UPDATE siswa SET nis='$data[0]', nama='$data[1]', jk='$data[2]', alamat='$data[3]', idk='$data[4]', tlp='$data[5]', bapak='$data[6]', k_bapak='$data[7]', ibu='$data[8]', k_ibu='$data[9]', pass='$mr' WHERE ids='$id'");
        break;

    case "siswa_det":
        $id = esc($koneksi, $_POST['id']);
        if (!empty($_POST['pass'])) {
            $pw = password_hash($_POST['pass'], PASSWORD_DEFAULT);
            mysqli_query($koneksi, "UPDATE siswa SET pass='$pw' WHERE ids='$id'");
        } else {
            alert_and_redirect('Isi Password', '../media.php?module=siswa_det');
            exit;
        }
        break;

    case "hapus":
        $ids = esc($koneksi, $_GET['ids']);
        mysqli_query($koneksi, "DELETE FROM siswa WHERE ids='$ids'");
        break;

    case "input_absen":
        $kelas = esc($koneksi, $_GET['kelas']);
        $tgl = esc($koneksi, $_GET['tanggal']);
        $idj = esc($koneksi, $_GET['idj']);
        $result = mysqli_query($koneksi, "SELECT * FROM siswa WHERE idk='$kelas'");
        while ($rs = mysqli_fetch_assoc($result)) {
            $ra = $rs['ids'];
            $ket = esc($koneksi, $_POST[$ra]);
            $check = mysqli_query($koneksi, "SELECT * FROM absen WHERE ids='$ra' AND tgl='$tgl' AND idj='$idj'");
            if (mysqli_num_rows($check) == 0) {
                mysqli_query($koneksi, "INSERT INTO absen(ids, idj, tgl, ket) VALUES('$ra', '$idj', '$tgl', '$ket')");
            } else {
                mysqli_query($koneksi, "UPDATE absen SET ket='$ket' WHERE ids='$ra' AND tgl='$tgl' AND idj='$idj'");
            }
        }
        break;

    case "input_sekolah":
        $kode = esc($koneksi, $_POST['kode']);
        $nama = esc($koneksi, $_POST['nama']);
        $alamat = esc($koneksi, $_POST['alamat']);
        mysqli_query($koneksi, "INSERT INTO sekolah(kode, nama, alamat) VALUES('$kode', '$nama', '$alamat')");
        break;

    case "edit_sekolah":
        $id = esc($koneksi, $_POST['id']);
        $kode = esc($koneksi, $_POST['kode']);
        $nama = esc($koneksi, $_POST['nama']);
        $alamat = esc($koneksi, $_POST['alamat']);
        mysqli_query($koneksi, "UPDATE sekolah SET kode='$kode', nama='$nama', alamat='$alamat' WHERE id='$id'");
        break;

    case "hapus_sekolah":
        $id = esc($koneksi, $_GET['id']);
        mysqli_query($koneksi, "DELETE FROM sekolah WHERE id='$id'");
        break;

    case "input_kelas":
        $id = esc($koneksi, $_POST['id']);
        $nama = esc($koneksi, $_POST['nama']);
        mysqli_query($koneksi, "INSERT INTO kelas(id, nama) VALUES('$id', '$nama')");
        break;

    case "edit_kelas":
        $idk = esc($koneksi, $_POST['idk']);
        $id = esc($koneksi, $_POST['id']);
        $nama = esc($koneksi, $_POST['nama']);
        mysqli_query($koneksi, "UPDATE kelas SET id='$id', nama='$nama' WHERE idk='$idk'");
        break;

    case "hapus_kelas":
        $idk = esc($koneksi, $_GET['idk']);
        mysqli_query($koneksi, "DELETE FROM kelas WHERE idk='$idk'");
        break;

    case "input_pelajaran":
        $nama_mp = esc($koneksi, $_POST['nama_mp']);
        mysqli_query($koneksi, "INSERT INTO mata_pelajaran(nama_mp) VALUES('$nama_mp')");
        break;

    case "edit_pelajaran":
        $idm = esc($koneksi, $_POST['idm']);
        $nama_mp = esc($koneksi, $_POST['nama_mp']);
        mysqli_query($koneksi, "UPDATE mata_pelajaran SET nama_mp='$nama_mp' WHERE idm='$idm'");
        break;

    case "hapus_pelajaran":
        $idm = esc($koneksi, $_GET['idm']);
        mysqli_query($koneksi, "DELETE FROM mata_pelajaran WHERE idm='$idm'");
        break;

    case "input_jadwal":
        $hari = esc($koneksi, $_POST['hari']);
        $guru = esc($koneksi, $_POST['guru']);
        $kelas = esc($koneksi, $_POST['kelas']);
        $pelajaran = esc($koneksi, $_POST['pelajaran']);
        $jam_mulai = esc($koneksi, $_POST['jam_mulai']);
        $jam_selesai = esc($koneksi, $_POST['jam_selesai']);
        mysqli_query($koneksi, "INSERT INTO jadwal(idh, idg, idk, idm, jam_mulai, jam_selesai) VALUES('$hari', '$guru', '$kelas', '$pelajaran', '$jam_mulai', '$jam_selesai')");
        break;

    case "edit_jadwal":
        $idj = esc($koneksi, $_POST['idj']);
        $hari = esc($koneksi, $_POST['hari']);
        $guru = esc($koneksi, $_POST['guru']);
        $kelas = esc($koneksi, $_POST['kelas']);
        $pelajaran = esc($koneksi, $_POST['pelajaran']);
        $jam_mulai = esc($koneksi, $_POST['jam_mulai']);
        $jam_selesai = esc($koneksi, $_POST['jam_selesai']);
        mysqli_query($koneksi, "UPDATE jadwal SET idh='$hari', idg='$guru', idk='$kelas', idm='$pelajaran', jam_mulai='$jam_mulai', jam_selesai='$jam_selesai' WHERE idj='$idj'");
        break;

    case "hapus_jadwal":
        $idj = esc($koneksi, $_GET['idj']);
        mysqli_query($koneksi, "DELETE FROM jadwal WHERE idj='$idj'");
        break;

    case "input_guru":
        $mrg = password_hash($_POST['k_password'], PASSWORD_DEFAULT);
        $fields = ['nip','nama','jk','alamat','kelas'];
        $data = array_map(function($field) use ($koneksi) {
            return esc($koneksi, $_POST[$field]);
        }, $fields);
        mysqli_query($koneksi, "INSERT INTO guru(nip, nama, jk, alamat, idg, pass) VALUES('$data[0]', '$data[1]', '$data[2]', '$data[3]', '$data[4]', '$mrg')");
        break;

    case "edit_guru":
        $idg = esc($koneksi, $_POST['idg']);
        $mrg = password_hash($_POST['k_password'], PASSWORD_DEFAULT);
        $fields = ['nip','nama','jk','alamat','kelas'];
        $data = array_map(function($field) use ($koneksi) {
            return esc($koneksi, $_POST[$field]);
        }, $fields);
        mysqli_query($koneksi, "UPDATE guru SET nip='$data[0]', nama='$data[1]', jk='$data[2]', alamat='$data[3]', idk='$data[4]', pass='$mrg' WHERE idg='$idg'");
        break;

    case "hapus_guru":
        $idg = esc($koneksi, $_GET['idg']);
        mysqli_query($koneksi, "DELETE FROM guru WHERE idg='$idg'");
        break;

    case "guru_det":
        $idg = esc($koneksi, $_POST['idg']);
        $nama = esc($koneksi, $_POST['nama']);
        $jk = esc($koneksi, $_POST['jk']);
        $alamat = esc($koneksi, $_POST['alamat']);
        if (!empty($_POST['pass'])) {
            $pw = password_hash($_POST['pass'], PASSWORD_DEFAULT);
            mysqli_query($koneksi, "UPDATE guru SET nama='$nama', jk='$jk', alamat='$alamat', pass='$pw' WHERE idg='$idg'");
        } else {
            mysqli_query($koneksi, "UPDATE guru SET nama='$nama', jk='$jk', alamat='$alamat' WHERE idg='$idg'");
        }
        break;
}

function alert_and_redirect($message, $location) {
    echo "<script>alert('$message'); window.location.href='$location';</script>";
    exit;
}

alert_and_redirect('Data Tersimpan', '../media.php?module=' . ($_GET['module'] ?? 'home'));