<?php
// Pastikan session aktif
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Gunakan koneksi mysqli
include __DIR__ . "/../../config/conn.php";

?><div class="row">
    <div class="col-lg-12">
        <h3 class="page-header"><strong>Data Kelas</strong></h3>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-primary">
            <div class="panel-heading">Data Kelas</div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th class="text-center">Kode Sekolah</th>
                                <th class="text-center">Nama Sekolah</th>
                                <th class="text-center">Kelas</th>
                                <th class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
                            $sql = mysqli_query($koneksi, "SELECT * FROM kelas");
                            while ($rs = mysqli_fetch_assoc($sql)) {
                                $sqla = mysqli_query($koneksi, "SELECT * FROM sekolah WHERE id='" . $rs['id'] . "'");
                                $rsa = mysqli_fetch_assoc($sqla);if ($_SESSION['level'] == "admin_guru") {
                                if (isset($rsa['id']) && $rsa['id'] == $_SESSION['id']) {
                                    ?>
                                    <tr class="odd gradeX">
                                        <td><?= htmlspecialchars($rsa['kode']) ?></td>
                                        <td><?= htmlspecialchars($rsa['nama']) ?></td>
                                        <td class="text-center"><?= htmlspecialchars($rs['nama']) ?></td>
                                        <td class="text-center">
                                            <a href="./././media.php?module=input_kelas&act=edit_kelas&idk=<?= $rs['idk'] ?>">
                                                <button type="button" class="btn btn-info">Edit</button>
                                            </a>
                                            <a href="././module/simpan.php?act=hapus_kelas&idk=<?= $rs['idk'] ?>" onclick="return confirm('Yakin ingin menghapus data ini?');">
                                                <button type="button" class="btn btn-danger">Hapus</button>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php
                                }
                            } else {
                                ?>
                                <tr class="odd gradeX">
                                    <td><?= htmlspecialchars($rsa['kode']) ?></td>
                                    <td><?= htmlspecialchars($rsa['nama']) ?></td>
                                    <td class="text-center"><?= htmlspecialchars($rs['nama']) ?></td>
                                    <td class="text-center">
                                        <a href="./././media.php?module=input_kelas&act=edit_kelas&idk=<?= $rs['idk'] ?>">
                                            <button type="button" class="btn btn-info">Edit</button>
                                        </a>
                                        <a href="././module/simpan.php?act=hapus_kelas&idk=<?= $rs['idk'] ?>" onclick="return confirm('Yakin ingin menghapus data ini?');">
                                            <button type="button" class="btn btn-danger">Hapus</button>
                                        </a>
                                    </td>
                                </tr>
                                <?php
                            }
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

</div>