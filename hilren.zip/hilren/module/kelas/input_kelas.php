<?php
// Pastikan session dimulai
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Gunakan koneksi MySQLi dan hindari mysql_* yang sudah deprecated
include __DIR__ . "/../../config/conn.php";

if (isset($_GET['act']) && $_GET['act'] == "input") {
?><div class="row">
    <div class="col-lg-12">
        <h3 class="page-header"><strong>Input Data Kelas</strong></h3>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-primary">
            <div class="panel-heading">Input Data Kelas</div>
            <div class="panel-body">
                <div class="row">
                    <form method="post" role="form" action="././module/simpan.php?act=input_kelas">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Nama Sekolah</label>
                                <select class="form-control" name="id">
                                    <?php
                                    $sql = mysqli_query($koneksi, "SELECT * FROM sekolah");
                                    while ($rs = mysqli_fetch_assoc($sql)) {
                                        if ($_SESSION['level'] == "admin_guru") {
                                            if ($rs['id'] == $_SESSION['id']) {
                                                echo "<option value='{$rs['id']}'>{$rs['nama']}</option>";
                                            }
                                        } else {
                                            echo "<option value='{$rs['id']}'>{$rs['nama']}</option>";
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Nama Kelas</label>
                                <input class="form-control" placeholder="Kelas" name="nama">
                            </div>
                            <button type="submit" class="btn btn-success">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
}if (isset($_GET['act']) && $_GET['act'] == "edit_kelas") { $idk = $_GET['idk'] ?? ''; $sql = mysqli_query($koneksi, "SELECT * FROM kelas WHERE idk='$idk'"); $rs = mysqli_fetch_assoc($sql); ?> <div class="row"> <div class="col-lg-12"> <h1 class="page-header">Edit Data Kelas</h1> </div> </div> <div class="row"> <div class="col-lg-12"> <div class="panel panel-primary"> <div class="panel-heading">Edit Data Kelas</div> <div class="panel-body"> <div class="row"> <form method="post" role="form" action="././module/simpan.php?act=edit_kelas"> <input type="hidden" name="idk" value="<?php echo htmlspecialchars($idk); ?>"> <div class="col-lg-6"> <div class="form-group"> <label>Kelas</label> <select class="form-control" name="id"> <?php
$sqla = mysqli_query($koneksi, "SELECT * FROM sekolah");
while ($rsa = mysqli_fetch_assoc($sqla)) {
if ($_SESSION['level'] == "admin_guru") {
if ($rsa['id'] == $_SESSION['id']) {
$selected = ($rs['id'] == $rsa['id']) ? "selected" : "";
echo "<option value='{$rsa['id']}' $selected>{$rsa['nama']}</option>";
}
} else {
$selected = ($rs['id'] == $rsa['id']) ? "selected" : "";
echo "<option value='{$rsa['id']}' $selected>{$rsa['nama']}</option>";
}
}
?> </select> </div> <div class="form-group"> <label>Nama Sekolah</label> <input class="form-control" placeholder="Kelas" name="nama" value="<?php echo htmlspecialchars($rs['nama']); ?>"> </div> <button type="submit" class="btn btn-success">Simpan</button> </div> </form> </div> </div> </div> </div> </div>

<?php
} 
?>