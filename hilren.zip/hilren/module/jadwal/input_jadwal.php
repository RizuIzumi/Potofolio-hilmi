<?php
include __DIR__ . "/../../config/conn.php"; // pastikan koneksi disiapkan
if ($_GET['act'] == "input") {
?>
<div class="row">
    <div class="col-lg-12">
        <h3 class="page-header"><strong>Input Data Jadwal</strong></h3>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-primary">
            <div class="panel-heading">Input Data Jadwal</div>
            <div class="panel-body">
                <div class="row">
                    <form method="post" role="form" action="././module/simpan.php?act=input_jadwal">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Hari</label>
                                <select class="form-control" name="hari" required>
                                    <option>--Pilih Hari--</option>
                                    <?php
                                    $sql = mysqli_query($koneksi, "SELECT * FROM hari");
                                    while ($rs = mysqli_fetch_array($sql)) {
                                        echo "<option value='$rs[idh]'>$rs[hari]</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Jam Mulai</label>
                                <input type="time" class="form-control" name="jam_mulai" required>
                            </div>
                            <div class="form-group">
                                <label>Jam Selesai</label>
                                <input type="time" class="form-control" name="jam_selesai" required>
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Mata Pelajaran</label>
                                <select class="form-control" name="pelajaran" required>
                                    <option>--Pilih Mata Pelajaran--</option>
                                    <?php
                                    $sql = mysqli_query($koneksi, "SELECT * FROM mata_pelajaran");
                                    while ($rs = mysqli_fetch_array($sql)) {
                                        echo "<option value='$rs[idm]'>$rs[nama_mp]</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Kelas</label>
                                <select class="form-control" name="kelas" required>
                                    <option>--Pilih Kelas--</option>
                                    <?php
                                    $sql = mysqli_query($koneksi, "SELECT * FROM kelas");
                                    while ($rs = mysqli_fetch_array($sql)) {
                                        echo "<option value='$rs[idk]'>$rs[nama]</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Guru</label>
                                <select class="form-control" name="guru" required>
                                    <option>--Pilih Guru--</option>
                                    <?php
                                    $sql = mysqli_query($koneksi, "SELECT * FROM guru");
                                    while ($rs = mysqli_fetch_array($sql)) {
                                        echo "<option value='$rs[idg]'>$rs[nama]</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-lg-12 text-center">
                            <button type="submit" class="btn btn-success">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php } ?>

<?php
if ($_GET['act'] == "edit_jadwal") {
    $idj = $_GET['idj'];
    $sql = mysqli_query($koneksi, "SELECT * FROM jadwal WHERE idj='$idj'");
    $rsx = mysqli_fetch_array($sql);
?>
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">Edit Data Jadwal</h1>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-primary">
            <div class="panel-heading">Edit Data Jadwal</div>
            <div class="panel-body">
                <div class="row">
                    <form method="post" role="form" action="././module/simpan.php?act=edit_jadwal">
                        <input type="hidden" name="idj" value="<?php echo $idj; ?>">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Hari</label>
                                <select class="form-control" name="hari" required>
                                    <option disabled>--Pilih Hari--</option>
                                    <?php
                                    $sql = mysqli_query($koneksi, "SELECT * FROM hari");
                                    while ($row = mysqli_fetch_array($sql)) {
                                        $selected = ($row['idh'] == $rsx['idh']) ? 'selected' : '';
                                        echo "<option value='{$row['idh']}' $selected>{$row['hari']}</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Jam Mulai</label>
                                <input type="time" class="form-control" name="jam_mulai" value="<?php echo $rsx['jam_mulai']; ?>">
                            </div>
                            <div class="form-group">
                                <label>Jam Selesai</label>
                                <input type="time" class="form-control" name="jam_selesai" value="<?php echo $rsx['jam_selesai']; ?>">
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Mata Pelajaran</label>
                                <select class="form-control" name="pelajaran" required>
                                    <option disabled>--Pilih Mata Pelajaran--</option>
                                    <?php
                                    $sql = mysqli_query($koneksi, "SELECT * FROM mata_pelajaran");
                                    while ($row = mysqli_fetch_array($sql)) {
                                        $selected = ($row['idm'] == $rsx['idm']) ? 'selected' : '';
                                        echo "<option value='{$row['idm']}' $selected>{$row['nama_mp']}</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Kelas</label>
                                <select class="form-control" name="kelas" required>
                                    <option disabled>--Pilih Kelas--</option>
                                    <?php
                                    $sql = mysqli_query($koneksi, "SELECT * FROM kelas");
                                    while ($row = mysqli_fetch_array($sql)) {
                                        $selected = ($row['idk'] == $rsx['idk']) ? 'selected' : '';
                                        echo "<option value='{$row['idk']}' $selected>{$row['nama']}</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Guru</label>
                                <select class="form-control" name="guru" required>
                                    <option disabled>--Pilih Guru--</option>
                                    <?php
                                    $sql = mysqli_query($koneksi, "SELECT * FROM guru");
                                    while ($row = mysqli_fetch_array($sql)) {
                                        $selected = ($row['idg'] == $rsx['idg']) ? 'selected' : '';
                                        echo "<option value='{$row['idg']}' $selected>{$row['nama']}</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-lg-12 text-center">
                            <button type="submit" class="btn btn-success">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php } ?>