<?php
// Perbaikan: gunakan mysqli dan sanitasi input, cek keamanan session

include __DIR__ . "/../../config/conn.php"; // Pastikan koneksi sudah disiapkan sebelumnya

$act = isset($_GET['act']) ? $_GET['act'] : '';

if ($act == "input") {
?>
<div class="row">
    <div class="col-lg-12">
        <h3 class="page-header"><strong>Input Data Siswa</strong></h3>
        
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-primary">
            <div class="panel-heading">Input Data Siswa</div>
            <div class="panel-body">
                <div class="row">
                    <form method="post" role="form" action="././module/simpan.php?act=input_siswa">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>NIS</label>
                                <input class="form-control" placeholder="NIS" name="nis" required>
                            </div>
                            <div class="form-group">
                                <label>Nama</label>
                                <input class="form-control" placeholder="Nama" name="nama" required>
                            </div>
                            <div class="form-group">
                                <label>Jenis Kelamin</label>
                                <div class="radio">
                                    <label><input type="radio" name="jk" value="L" checked> Laki - Laki</label>
                                </div>
                                <div class="radio">
                                    <label><input type="radio" name="jk" value="P"> Perempuan</label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Alamat</label>
                                <textarea class="form-control" placeholder="Alamat" name="alamat" rows="3" required></textarea>
                            </div>
                            <div class="form-group">
                                <label>Kelas</label>
                                <select class="form-control" name="kelas">
                                    <?php
                                    $query = mysqli_query($koneksi, "SELECT * FROM kelas");
                                    while ($kelas = mysqli_fetch_assoc($query)) {
                                        $sekolah = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT * FROM sekolah WHERE id='{$kelas['id']}'"));
                                        if ($_SESSION['level'] == 'admin_guru' && $sekolah['id'] != $_SESSION['id']) continue;
                                        echo "<option value='{$kelas['idk']}'>{$kelas['nama']}</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group input-group">
                                <span class="input-group-addon">+62</span>
                                <input type="text" class="form-control" placeholder="No Telepon" name="tlp" required>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Nama Ayah</label>
                                <input class="form-control" placeholder="Nama Ayah" name="bapak">
                            </div>
                            <div class="form-group">
                                <label>Pekerjaan Ayah</label>
                                <input class="form-control" placeholder="Pekerjaan Ayah" name="k_bapak">
                            </div>
                            <div class="form-group">
                                <label>Nama Ibu</label>
                                <input class="form-control" placeholder="Nama Ibu" name="ibu">
                            </div>
                            <div class="form-group">
                                <label>Pekerjaan Ibu</label>
                                <input class="form-control" placeholder="Pekerjaan Ibu" name="k_ibu">
                            </div>
                            <div class="form-group">
                                <label>Password</label>
                                <input class="form-control" placeholder="Password" name="k_password" type="password" required>
                            </div>
                            <button type="submit" class="btn btn-success">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php }

if ($act == "edit") {
    $ids = mysqli_real_escape_string($koneksi, $_GET['ids']);
    $query = mysqli_query($koneksi, "SELECT * FROM siswa WHERE ids='$ids'");
    $data = mysqli_fetch_assoc($query);
?>
<div class="row">
    <div class="col-lg-12">
        <h3 class="page-header"><strong>Edit Data Siswa</strong></h3>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-primary">
            <div class="panel-heading">Edit Data Siswa</div>
            <div class="panel-body">
                <div class="row">
                    <form method="post" role="form" action="././module/simpan.php?act=edit_siswa">
                        <input type="hidden" name="id" value="<?= $ids ?>">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>NIS</label>
                                <input class="form-control" name="nis" value="<?= htmlspecialchars($data['nis']) ?>" required>
                            </div>
                            <div class="form-group">
                                <label>Nama</label>
                                <input class="form-control" name="nama" value="<?= htmlspecialchars($data['nama']) ?>" required>
                            </div>
                            <div class="form-group">
                                <label>Jenis Kelamin</label>
                                <div class="radio">
                                    <label><input type="radio" name="jk" value="L" <?= $data['jk'] == 'L' ? 'checked' : '' ?>> Laki - Laki</label>
                                </div>
                                <div class="radio">
                                    <label><input type="radio" name="jk" value="P" <?= $data['jk'] == 'P' ? 'checked' : '' ?>> Perempuan</label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Alamat</label>
                                <textarea class="form-control" name="alamat" rows="3"><?= htmlspecialchars($data['alamat']) ?></textarea>
                            </div>
                            <div class="form-group">
                                <label>Kelas</label>
                                <select class="form-control" name="kelas">
                                    <?php
                                    $kelasQuery = mysqli_query($koneksi, "SELECT * FROM kelas");
                                    while ($kelas = mysqli_fetch_assoc($kelasQuery)) {
                                        $sekolah = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT * FROM sekolah WHERE id='{$kelas['id']}'"));
                                        if ($_SESSION['level'] == 'admin_guru' && $sekolah['id'] != $_SESSION['id']) continue;
                                        $selected = $data['idk'] == $kelas['idk'] ? 'selected' : '';
                                        echo "<option value='{$kelas['idk']}' $selected>{$kelas['nama']}</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group input-group">
                                <span class="input-group-addon">+62</span>
                                <input type="text" class="form-control" name="tlp" value="<?= htmlspecialchars($data['tlp']) ?>">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Nama Ayah</label>
                                <input class="form-control" name="bapak" value="<?= htmlspecialchars($data['bapak']) ?>">
                            </div>
                            <div class="form-group">
                                <label>Pekerjaan Ayah</label>
                                <input class="form-control" name="k_bapak" value="<?= htmlspecialchars($data['k_bapak']) ?>">
                            </div>
                            <div class="form-group">
                                <label>Nama Ibu</label>
                                <input class="form-control" name="ibu" value="<?= htmlspecialchars($data['ibu']) ?>">
                            </div>
                            <div class="form-group">
                                <label>Pekerjaan Ibu</label>
                                <input class="form-control" name="k_ibu" value="<?= htmlspecialchars($data['k_ibu']) ?>">
                            </div>
                            <div class="form-group">
                                <label>Password</label>
                                <input class="form-control" name="k_password" type="password">
                            </div>
                            <button type="submit" class="btn btn-success">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php } ?>