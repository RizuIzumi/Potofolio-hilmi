<?php
// Mengambil parameter kelas dari URL
$klas = $_GET['kls'] ?? 'semua';

?>
<div class="row">
    <div class="col-lg-12">
        <h3 class="page-header"><strong>Data Siswa</strong></h3>
         <a href="media.php?module=tampil" class="btn btn-primary" style="margin-bottom:15px;">
            <i class="fa fa-arrow-left"></i> Kembali
        </a>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <?php
                if ($klas == "semua") {
                    echo "Data Semua Siswa";
                } else {
                    $claris = mysqli_query($koneksi, "SELECT * FROM kelas WHERE idk='$klas'");
                    $click = mysqli_fetch_assoc($claris);
                    echo "Data Siswa Kelas {$click['nama']}";
                }
                ?>
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th class="text-center">NIS</th>
                                <th class="text-center" width="30%">Nama</th>
                                <th class="text-center">JK</th>
                                <th class="text-center">Kelas</th>
                                <th class="text-center">No Telepon</th>
                                <th class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $query = ($klas == "semua") ? "SELECT * FROM siswa" : "SELECT * FROM siswa WHERE idk='$klas'";
                            $sql = mysqli_query($koneksi, $query);

                            while ($rs = mysqli_fetch_assoc($sql)) {
                                $sqlw = mysqli_query($koneksi, "SELECT * FROM kelas WHERE idk='{$rs['idk']}'");
                                $rsw = mysqli_fetch_assoc($sqlw);

                                $sqlb = mysqli_query($koneksi, "SELECT * FROM sekolah WHERE id='{$rsw['id']}'");
                                $rsb = mysqli_fetch_assoc($sqlb);

                                if ($_SESSION['level'] == "admin_guru" && $rsb['id'] != $_SESSION['id']) {
                                    continue;
                                }

                                $nama_kelas = mysqli_query($koneksi, "SELECT nama FROM kelas WHERE idk='{$rs['idk']}'");
                                $kelas_data = mysqli_fetch_assoc($nama_kelas);
                                ?>
                                <tr class="odd gradeX">
                                    <td><?= htmlspecialchars($rs['nis']) ?></td>
                                    <td><?= htmlspecialchars($rs['nama']) ?></td>
                                    <td class="text-center">
                                        <?= ($rs['jk'] == 'L') ? 'Laki - Laki' : 'Perempuan' ?>
                                    </td>
                                    <td><?= htmlspecialchars($kelas_data['nama']) ?></td>
                                    <td><?= htmlspecialchars($rs['tlp']) ?></td>
                                    <td class="text-center">
                                        <a href="media.php?module=detail_siswa&act=details&ids=<?= $rs['ids'] ?>">
                                            <button type="button" class="btn btn-warning">Details</button>
                                        </a>
                                        <a href="media.php?module=input_siswa&act=edit&ids=<?= $rs['ids'] ?>">
                                            <button type="button" class="btn btn-info">Edit</button>
                                        </a>
                                        <a href="module/simpan.php?act=hapus&ids=<?= $rs['ids'] ?>" onclick="return confirm('Yakin ingin menghapus?')">
                                            <button type="button" class="btn btn-danger">Hapus</button>
                                        </a>
                                    </td>
                                </tr>
                                <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>