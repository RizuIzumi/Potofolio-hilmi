<?php
// Pastikan menggunakan koneksi mysqli dan validasi input
$nis = mysqli_real_escape_string($koneksi, $_SESSION['idu']);
$sql = mysqli_query($koneksi, "SELECT * FROM siswa WHERE nis='$nis'");
$rs = mysqli_fetch_array($sql);
?><div class="row">
    <div class="col-lg-12">
        <h3 class="page-header"><strong>Data Siswa</strong></h3>
         <a href="media.php?module=siswa" class="btn btn-primary" style="margin-bottom:15px;">
            <i class="fa fa-arrow-left"></i> Kembali
        </a>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-primary">
            <div class="panel-heading">Data Siswa</div>
            <div class="panel-body">
                <div class="row">
                    <form method="post" role="form" action="././module/simpan.php?act=siswa_det">
                        <input type="hidden" name="id" value="<?= htmlspecialchars($rs['ids']) ?>" /><div class="col-lg-6">
                        <fieldset disabled>
                            <div class="form-group">
                                <label>NIS</label>
                                <input class="form-control" name="nis" value="<?= htmlspecialchars($rs['nis']) ?>">
                            </div>
                            <div class="form-group">
                                <label>Nama</label>
                                <input class="form-control" name="nama" value="<?= htmlspecialchars($rs['nama']) ?>">
                            </div>
                            <div class="form-group">
                                <label>Jenis Kelamin</label>
                                <div class="radio">
                                    <label><input type="radio" name="jk" value="L" <?= $rs['jk'] == 'L' ? 'checked' : '' ?>> Laki - Laki</label>
                                </div>
                                <div class="radio">
                                    <label><input type="radio" name="jk" value="P" <?= $rs['jk'] == 'P' ? 'checked' : '' ?>> Perempuan</label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Alamat</label>
                                <textarea class="form-control" name="alamat" rows="3"><?= htmlspecialchars($rs['alamat']) ?></textarea>
                            </div>
                            <div class="form-group">
                                <label>Kelas</label>
                                <select class="form-control" name="kelas">
                                    <?php
                                    $sqlc = mysqli_query($koneksi, "SELECT * FROM kelas");
                                    while ($rsc = mysqli_fetch_array($sqlc)) {
                                        $sqla = mysqli_query($koneksi, "SELECT * FROM sekolah WHERE id='" . $rsc['id'] . "'");
                                        $rsa = mysqli_fetch_array($sqla);
                                        if ($_SESSION['level'] == "admin_guru" && $rsa['id'] != $_SESSION['id']) continue;
                                        $selected = ($rs['idk'] == $rsc['idk']) ? 'selected' : '';
                                        echo "<option value='{$rsc['idk']}' $selected>{$rsc['nama']}</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group input-group">
                                <span class="input-group-addon">+62</span>
                                <input type="text" class="form-control" name="tlp" value="<?= htmlspecialchars($rs['tlp']) ?>">
                            </div>
                        </fieldset>
                    </div>

                    <div class="col-lg-6">
                        <fieldset disabled>
                            <div class="form-group">
                                <label>Nama Ayah</label>
                                <input class="form-control" name="bapak" value="<?= htmlspecialchars($rs['bapak']) ?>">
                            </div>
                            <div class="form-group">
                                <label>Pekerjaan Ayah</label>
                                <input class="form-control" name="k_bapak" value="<?= htmlspecialchars($rs['k_bapak']) ?>">
                            </div>
                            <div class="form-group">
                                <label>Nama Ibu</label>
                                <input class="form-control" name="ibu" value="<?= htmlspecialchars($rs['ibu']) ?>">
                            </div>
                            <div class="form-group">
                                <label>Pekerjaan Ibu</label>
                                <input class="form-control" name="k_ibu" value="<?= htmlspecialchars($rs['k_ibu']) ?>">
                            </div>
                        </fieldset>
                        <div class="form-group">
                            <label>Ganti Password</label>
                            <input class="form-control" type="password" name="pass" placeholder="Password baru">
                        </div>
                        <button type="submit" class="btn btn-success">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

</div>