<?php
// Pastikan sudah include koneksi ke database
require_once __DIR__ . "/../../config/conn.php";
?><div class="row">
    <div class="col-lg-12">
        <h3 class="page-header"><strong>Data Siswa Per-Kelas</strong></h3>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-primary">
            <div class="panel-heading">
                Pilih Kelas
            </div>
            <div class="panel-body">
                <div class="row">
                    <form method="get" role="form" action="././media.php">
                        <input type="hidden" name="module" value="siswa">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Kelas</label>
                                <select class="form-control" name="kls">
                                    <?php
                                    if ($_SESSION['level'] == "guru") {
                                        $query = mysqli_query($koneksi, "SELECT * FROM kelas WHERE idk='" . $_SESSION['idk'] . "'");
                                    } else {
                                        echo '<option value="semua">Semua</option>';
                                        $query = mysqli_query($koneksi, "SELECT * FROM kelas");
                                    }
                                    while ($rs = mysqli_fetch_assoc($query)) {
                                        echo "<option value='{$rs['idk']}'>{$rs['nama']}</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-success">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>