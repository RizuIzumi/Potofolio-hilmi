<?php
// Pastikan file koneksi disertakan
include __DIR__ . "/../../config/conn.php";

// Cegah SQL Injection (gunakan prepared statement lebih baik, ini minimal sanitasi)
$ids = isset($_GET['ids']) ? intval($_GET['ids']) : 0;

// Ambil data siswa
$sql = mysqli_query($koneksi, "SELECT * FROM siswa WHERE ids='$ids'");
$rs = mysqli_fetch_assoc($sql);
?>

<div class="row">
    <div class="col-lg-12">
        <h3 class="page-header"><strong>Detail Siswa: <?php echo htmlspecialchars($rs['nama']); ?></strong></h3>
        <a href="media.php?module=tampil" class="btn btn-primary" style="margin-bottom:15px;">
            <i class="fa fa-arrow-left"></i> Kembali
        </a>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-primary">
            <div class="panel-heading">Data Siswa</div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-6">
                        <fieldset disabled>
                            <div class="form-group">
                                <label>NIS</label>
                                <input class="form-control" value="<?php echo htmlspecialchars($rs['nis']); ?>">
                            </div>
                            <div class="form-group">
                                <label>Nama</label>
                                <input class="form-control" value="<?php echo htmlspecialchars($rs['nama']); ?>">
                            </div>
                            <div class="form-group">
                                <label>Jenis Kelamin</label>
                                <div class="radio">
                                    <label>
                                        <input type="radio" name="jk" value="L" <?php if ($rs['jk'] == "L") echo "checked"; ?>> Laki - Laki
                                    </label>
                                </div>
                                <div class="radio">
                                    <label>
                                        <input type="radio" name="jk" value="P" <?php if ($rs['jk'] == "P") echo "checked"; ?>> Perempuan
                                    </label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Alamat</label>
                                <textarea class="form-control" rows="3"><?php echo htmlspecialchars($rs['alamat']); ?></textarea>
                            </div>
                            <div class="form-group">
                                <label>Kelas</label>
                                <select class="form-control">
                                    <?php
                                    $sqlc = mysqli_query($koneksi, "SELECT * FROM kelas");
                                    while ($rsc = mysqli_fetch_assoc($sqlc)) {
                                        $sqla = mysqli_query($koneksi, "SELECT * FROM sekolah WHERE id='{$rsc['id']}'");
                                        $rsa = mysqli_fetch_assoc($sqla);

                                        if ($_SESSION['level'] == "admin_guru" && $rsa['id'] != $_SESSION['id']) {
                                            continue;
                                        }

                                        $selected = ($rs['idk'] == $rsc['idk']) ? "selected" : "";
                                        echo "<option value='{$rsc['idk']}' $selected>{$rsc['nama']}</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group input-group">
                                <span class="input-group-addon">+62</span>
                                <input type="text" class="form-control" value="<?php echo htmlspecialchars($rs['tlp']); ?>">
                            </div>
                        </fieldset>
                    </div>

                    <div class="col-lg-6">
                        <fieldset disabled>
                            <div class="form-group">
                                <label>Nama Ayah</label>
                                <input class="form-control" value="<?php echo htmlspecialchars($rs['bapak']); ?>">
                            </div>
                            <div class="form-group">
                                <label>Pekerjaan Ayah</label>
                                <input class="form-control" value="<?php echo htmlspecialchars($rs['k_bapak']); ?>">
                            </div>
                            <div class="form-group">
                                <label>Nama Ibu</label>
                                <input class="form-control" value="<?php echo htmlspecialchars($rs['ibu']); ?>">
                            </div>
                            <div class="form-group">
                                <label>Pekerjaan Ibu</label>
                                <input class="form-control" value="<?php echo htmlspecialchars($rs['k_ibu']); ?>">
                            </div>
                        </fieldset>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>