<div class="row">
    <div class="col-lg-12">
        <h3 class="page-header"><strong>Jadwal Belajar</strong></h3>
    </div>
</div>

<?php
// Pastikan koneksi sudah dibuat sebelumnya dengan $koneksi
$klss = mysqli_real_escape_string($koneksi, $klss);

// Ambil informasi kelas
$result_kelas = mysqli_query($koneksi, "SELECT * FROM kelas WHERE idk='$klss'");
$kelas = mysqli_fetch_assoc($result_kelas);
?>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-primary">
            <div class="panel-heading">
                Jadwal Belajar Kelas <?= $kelas['nama'] ?>
            </div>

            <ul class="nav nav-tabs">
                <li role="presentation"><a href="media.php?module=siswa_senin">Senin</a></li>
                <li role="presentation"><a href="media.php?module=siswa_selasa">Selasa</a></li>
                <li role="presentation"><a href="media.php?module=siswa_rabu">Rabu</a></li>
                <li role="presentation" class="active"><a href="media.php?module=siswa_kamis">Kamis</a></li>
                <li role="presentation"><a href="media.php?module=siswa_jumat">Jum'at</a></li>
            </ul>

            <br>

            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover">
                        <thead>
                            <tr>
                                <th class="text-center">No</th>
                                <th class="text-center">Hari</th>
                                <th class="text-center">Jam</th>
                                <th class="text-center">Guru Pengajar</th>
                                <th class="text-center">Mata Pelajaran</th>
                                <th class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
                            $query = "
                                SELECT 
                                    jadwal.idj, 
                                    hari.hari, 
                                    guru.nama AS nama_guru, 
                                    mata_pelajaran.nama_mp,
                                    jadwal.jam_mulai, 
                                    jadwal.jam_selesai 
                                FROM jadwal
                                JOIN hari ON jadwal.idh = hari.idh
                                JOIN guru ON jadwal.idg = guru.idg
                                JOIN mata_pelajaran ON jadwal.idm = mata_pelajaran.idm
                                WHERE jadwal.idh = 4 AND jadwal.idk = '$kelas[idk]'
                                ORDER BY jadwal.jam_mulai
                            ";
                            $result = mysqli_query($koneksi, $query);

                            while ($row = mysqli_fetch_assoc($result)) {
                            ?>
                                <tr class="odd gradeX">
                                    <td class="text-center"><?= $no++ ?></td>
                                    <td class="text-center"><?= $row['hari'] ?></td>
                                    <td class="text-center"><?= $row['jam_mulai'] . ' - ' . $row['jam_selesai'] ?></td>
                                    <td><?= $row['nama_guru'] ?></td>
                                    <td><?= $row['nama_mp'] ?></td>
                                    <td class="text-center">
                                        <a href="media.php?module=rekap_s&idj=<?= $row['idj'] ?>">
                                            <button type="button" class="btn btn-primary">Data Absen</button>
                                        </a>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div> <!-- /.table-responsive -->
            </div> <!-- /.panel-body -->
        </div> <!-- /.panel -->
    </div> <!-- /.col-lg-12 -->
</div> <!-- /.row -->