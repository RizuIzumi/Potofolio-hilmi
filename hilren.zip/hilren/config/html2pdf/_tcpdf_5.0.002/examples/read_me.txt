You can read the documentation at : http://www.tecnick.com/public/code/cp_dpage.php?aiocp_dp=tcpdf_examples

it has been removed because of the size of the package of HTML2PDF... 